<?php

return [
    'home' => 'Home',
    'contact' => 'Contact',
    'languages' => 'Languages',

    'legal' => 'Legal Advise',

];
