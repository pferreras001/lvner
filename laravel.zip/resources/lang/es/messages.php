<?php

return [
    'home' => 'Inicio',
    'contact' => 'Contacto',
    'languages' => 'Idiomas',

    'legal' => 'Aviso Legal',

];
