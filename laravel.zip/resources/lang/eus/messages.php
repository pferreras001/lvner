<?php

return [
    'home' => 'Hasi',
    'contact' => 'Harremana',
    'languages' => 'Hizkuntza',

    'legal' => 'Abisu Legala',

];
