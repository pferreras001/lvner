<section class="section footer">
  <div class="footer__container container">
    <div>LVNER © {{ now()->year }} · <a href="">{{ __('messages.legal') }}</a></div>
  </div>
</section>