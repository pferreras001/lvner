<section class="section home">
  <div class="home__container">
    <div class="home__left">
      <?php require('img/home/logo.svg')?>
    </div>
    <div class="home__right">
      <picture>
        <source media="(min-width: 1025px)" srcset="img/home/photo01.jpg">
        <img src="img/home/photo01-s.jpg"" alt="default">
      </picture>
    </div>
  </div>
</section>