<section class="section video">
  <div class="video__container">
    <!--<iframe src="https://www.youtube.com/embed/tkBMc-xisXE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
    <video onloadedmetadata="this.muted=true" muted autoplay loop id="vid">
      <source src="videos/video/closing_doors_teaser.mp4" type="video/mp4">
    </video>
    <script>
      document.getElementById('vid').play();
    </script>
  </div>
</section>