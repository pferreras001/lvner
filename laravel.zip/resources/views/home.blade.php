@extends('layout')

@section('section')

  <x-home/>
  <x-video/>
  <x-contact/>

@endsection