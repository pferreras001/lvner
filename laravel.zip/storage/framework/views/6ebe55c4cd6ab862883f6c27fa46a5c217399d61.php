<?php $__env->startSection('section'); ?>

  <?php if (isset($component)) { $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home::class, []); ?>
<?php $component->withName('home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73)): ?>
<?php $component = $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73; ?>
<?php unset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Video::class, []); ?>
<?php $component->withName('video'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9)): ?>
<?php $component = $__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9; ?>
<?php unset($__componentOriginal39cf1ce2fe4a17f238e1e42f0ce9b232583486f9); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Contact::class, []); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed)): ?>
<?php $component = $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed; ?>
<?php unset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/lvner01/resources/views/home.blade.php ENDPATH**/ ?>