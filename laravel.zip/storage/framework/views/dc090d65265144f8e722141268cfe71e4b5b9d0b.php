<section class="section footer">
  <div class="footer__container container">
    <div>LVNER © <?php echo e(now()->year); ?> · <a href=""><?php echo e(__('messages.legal')); ?></a></div>
  </div>
</section><?php /**PATH /Users/admin/Documents/web_proyects/laravel/lvner01/resources/views/components/footer.blade.php ENDPATH**/ ?>